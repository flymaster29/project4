﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
[CustomEditor(typeof(PlanetBase))]
public class PlanetBaseInspector : Editor {
	float temp = 0;
	PlanetBase myTarget;
	bool atmosphere;
	bool life;
	bool surface;
	bool orbit;
	bool elements;
	public override void OnInspectorGUI ()
	{
		
		myTarget = (PlanetBase)target;
		atmosphere = EditorGUILayout.Foldout (atmosphere, "Atmosphere");
		if (atmosphere) {
			int level = EditorGUI.indentLevel;
			EditorGUI.indentLevel++;
			myTarget.hasWater = EditorGUILayout.Toggle ("Water?", myTarget.hasWater);
			myTarget.highTemp = EditorGUILayout.Slider (new GUIContent("High Temp?", "Earth is about 58 Celsius"), myTarget.highTemp, -250, 500);
			myTarget.lowTemp = EditorGUILayout.Slider (new GUIContent("Low Temp?", "Earth is about -89 Celsius"), myTarget.lowTemp, -250, 500);
			myTarget.radiationAmount = EditorGUILayout.Slider (new GUIContent("Radiation Amount?", "Earth has about 1.26 millisievert per year"), myTarget.radiationAmount, 0, 100);
			EditorGUI.indentLevel = level;
		}
		life = EditorGUILayout.Foldout (life, "Life");
		if (life) {
			int level = EditorGUI.indentLevel;
			EditorGUI.indentLevel++;
			myTarget.isHabitable  = EditorGUILayout.BeginToggleGroup ("Inhabitable?", myTarget.isHabitable);
			if (!myTarget.isHabitable) {
				myTarget.flora = false;
				myTarget.fauna = false;
			}
			myTarget.flora = EditorGUILayout.Toggle (new GUIContent("Flora?", "Think about plant life"), myTarget.flora);
			myTarget.fauna = EditorGUILayout.Toggle (new GUIContent("Fauna?", "Think about animal life"), myTarget.fauna);
			EditorGUILayout.EndToggleGroup ();
			myTarget.intelligentCreatures = EditorGUILayout.BeginToggleGroup ("Intelligent Creaturs?", myTarget.intelligentCreatures);
			myTarget.icPopulation = EditorGUILayout.IntField (new GUIContent("Population", "Earth has about 7 billion"), myTarget.icPopulation);
			EditorGUILayout.EndToggleGroup ();
			EditorGUI.indentLevel = level;
		}
		surface = EditorGUILayout.Foldout (surface, "Surface");
		if (surface) {
			int level = EditorGUI.indentLevel;
			EditorGUI.indentLevel++;
			myTarget.lowElevation = EditorGUILayout.Slider (new GUIContent("Low Elevation", "Think about caves"), myTarget.lowElevation, -1000, 1000);
			myTarget.highElevation = EditorGUILayout.Slider (new GUIContent("High Elevation", "Think about mountains"), myTarget.highElevation, -1000, 1000);
			myTarget.planetSize = EditorGUILayout.IntSlider (new GUIContent("Planet Size", "Earth is 7.9k miles"), myTarget.planetSize, 100, 10000);
			myTarget.mainColor = EditorGUILayout.ColorField ("Planet Color:", myTarget.mainColor);
			EditorGUI.indentLevel = level;
		}
		orbit = EditorGUILayout.Foldout (orbit, "Orbit");
		if (orbit) {
			int level = EditorGUI.indentLevel;
			EditorGUI.indentLevel++;
			myTarget.revolutionTime = EditorGUILayout.Slider (new GUIContent("Revolution Time", "Earth is 24 hours"), myTarget.revolutionTime, 0, 100);
			myTarget.orbitTime = EditorGUILayout.Slider (new GUIContent("Orbit Time", "Earth is 365 days"), myTarget.orbitTime, 0, 100);
			myTarget.moonAmount = EditorGUILayout.IntSlider ("Moon Amount: ", myTarget.moonAmount, 0, 24);
			EditorGUI.indentLevel = level;
		}
		elements = EditorGUILayout.Foldout (elements, "Elements");
		if (elements) {
			int level = EditorGUI.indentLevel;
			EditorGUI.indentLevel++;
			serializedObject.Update ();
			GUIStyle myStyle = new GUIStyle (GUI.skin.GetStyle ("Label"));
			myStyle.alignment = TextAnchor.MiddleCenter;
			SerializedProperty myElem = serializedObject.FindProperty ("mainElements");

			EditorGUILayout.PropertyField (myElem, new GUIContent("Main Elements", "Example: Helium"), true);
			serializedObject.ApplyModifiedProperties ();
			//myTarget.mainElements = EditorGUILayout.ObjectField (myTarget.mainElements, true);
			//myTarget.mainElements = EditorGUILayout.
			EditorGUI.indentLevel = level;
		}
		//GUILayout layout = new GUI.skin.horizontalSlider
		//myTarget.planetSize = EditorGUILayout.IntField ("Planet Size: ", myTarget.planetSize);

		//temp = EditorGUILayout.Slider ("Moon Amount: ", temp, 0, 100);
		//base.OnInspectorGUI ();
	}

	/*group
	 * Atmosphere: hasWater, hightemp, lowtemp, radiationamount
	 * life: ishabitable, flora, fauna, intelligent creatures, icpopulation
	 * surface: lowevelavtion, highelevation, planet size, maincolor
	 * orbit and time: revolutiontime, orbittime, moonAmount
	 * Main Elements: main elements.
	 * 
	 */

}
